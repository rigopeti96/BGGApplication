package hu.bme.aut.android.bggapplication.adapter

class GameListAdapter {
}