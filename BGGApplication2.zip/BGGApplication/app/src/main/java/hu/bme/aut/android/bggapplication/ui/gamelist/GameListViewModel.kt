package hu.bme.aut.android.bggapplication.ui.gamelist

import androidx.lifecycle.ViewModel

class GameListViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}