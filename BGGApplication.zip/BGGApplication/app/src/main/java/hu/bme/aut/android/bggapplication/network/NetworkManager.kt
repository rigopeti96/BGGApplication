package hu.bme.aut.android.bggapplication.network

object NetworkManager {
}