package hu.bme.aut.android.bggapplication.ui.gamedetails

import androidx.lifecycle.ViewModel

class GameDetailsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}