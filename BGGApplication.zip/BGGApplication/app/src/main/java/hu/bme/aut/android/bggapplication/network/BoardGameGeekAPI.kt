package hu.bme.aut.android.bggapplication.network

interface BoardGameGeekAPI {
}